#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def scrape_pollution_data():
    #Import necessary libraries
    import requests
    from bs4 import BeautifulSoup
    import pandas as pd 
    import numpy as np
    from datetime import datetime, timedelta
    # create an empty dataframe to store the data
    pollution_df_2020 = pd.DataFrame()
    pollution_df_2021 = pd.DataFrame()

    # loop through each state code and make the API call for that state
    for num in range(1, 57):
        # specify the API endpoint URL
        url = f'https://aqs.epa.gov/data/api/annualData/byState'

        # define the query parameters
        params_2020 = {
            'email': 'shebanader@gmail.com',
            'key': 'greygazelle65',
            'param': '88101',
            'bdate': '20200101',
            'edate': '20201231',
            'state': f'{num:02d}'
        }


        # make the API call
        response = requests.get(url, params=params_2020)

        # check that the API call was successful
        if response.status_code != 200:
            print(f'Error: API call for state {num:02d} returned status code {response.status_code}')

        # loop through each data point and extract the relevant data
        for data_point in response.json()['Data']:
            if data_point['parameter'] == 'PM2.5 - Local Conditions':
                state = data_point['state']
                year = data_point['year']
                pm25_mean = data_point['arithmetic_mean']

                # create a dataframe with the current data point
                data_2020 = {'State': state, 'Year': year, 'PM2.5 Mean': pm25_mean}
                temp_df_2020 = pd.DataFrame(data_2020, index=[0])

                # concatenate the new dataframe to the main dataframe
                pollution_df_2020 = pd.concat([pollution_df_2020, temp_df_2020], ignore_index=True)

    # group the dataframe by state and year and take the mean of the PM2.5 Mean column
    pollution_df_mean_2020 = pollution_df_2020.groupby(['State', 'Year'])['PM2.5 Mean'].mean().reset_index()

    # create a list of state names for the 50 US states
    us_states = ['Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut', 'Delaware', 'Florida', 'Georgia', 'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana', 'Maine', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota', 'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey', 'New Mexico', 'New York', 'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania', 'Rhode Island', 'South Carolina', 'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming']

    # filter the DataFrame to include only the US states
    pollution_df_mean_2020 = pollution_df_mean_2020[pollution_df_mean_2020['State'].isin(us_states)]

    for num in range(1, 57):
        # specify the API endpoint URL
        url = f'https://aqs.epa.gov/data/api/annualData/byState'

        # define the query parameters
        params_2021 = {
            'email': 'shebanader@gmail.com',
            'key': 'greygazelle65',
            'param': '88101',
            'bdate': '20210101',
            'edate': '20211231',
            'state': f'{num:02d}'
        }

        # make the API call
        response = requests.get(url, params=params_2021)

        # check that the API call was successful
        if response.status_code != 200:
            print(f'Error: API call for state {num:02d} returned status code {response.status_code}')

        # loop through each data point and extract the relevant data
        for data_point in response.json()['Data']:
            if data_point['parameter'] == 'PM2.5 - Local Conditions':
                state = data_point['state']
                year = data_point['year']
                pm25_mean = data_point['arithmetic_mean']

            # create a dataframe with the current data point
            data_2021 = {'State': state, 'Year': year, 'PM2.5 Mean': pm25_mean}
            temp_df_2021 = pd.DataFrame(data_2021, index=[0])

            # concatenate the new dataframe to the main dataframe
            pollution_df_2021 = pd.concat([pollution_df_2021, temp_df_2021], ignore_index=True)

    # group the dataframe by state and year and take the mean of the PM2.5 Mean column
    pollution_df_mean_2021 = pollution_df_2021.groupby(['State', 'Year'])['PM2.5 Mean'].mean().reset_index()

    # create a list of state names for the 50 US states
    us_states = ['Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut', 'Delaware', 'Florida', 'Georgia', 'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana', 'Maine', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota', 'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey', 'New Mexico', 'New York', 'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania', 'Rhode Island', 'South Carolina', 'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming']

    # filter the DataFrame to include only the US states
    pollution_df_mean_2021 = pollution_df_mean_2021[pollution_df_mean_2021['State'].isin(us_states)]


    #Combine the dataframes for 2020 and 2021 and print the combined data frame
    df_combined_2020_2021 = pd.concat([pollution_df_mean_2020, pollution_df_mean_2021])

    return df_combined_2020_2021

