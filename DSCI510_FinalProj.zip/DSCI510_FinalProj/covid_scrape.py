#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def scrape_covid_data():
    
    #Import necessary libraries
    import requests
    from bs4 import BeautifulSoup
    import pandas as pd 
    import numpy as np
    from datetime import datetime, timedelta

    states = ['AL', 'AK', 'AZ', 'AR', 'CA', 'CO', 'CT', 'DE', 'DC', 'FL', 'GA', 'HI', 'ID', 'IL', 'IN', 'IA', 'KS', 'KY', 'LA', 'ME', 'MD', 'MA', 'MI', 'MN', 'MS', 'MO', 'MT', 'NE', 'NV', 'NH', 'NJ', 'NM', 'NY', 'NC', 'ND', 'OH', 'OK', 'OR', 'PA', 'RI', 'SC', 'SD', 'TN', 'TX', 'UT', 'VT', 'VA', 'WA', 'WV', 'WI', 'WY']

    # Set the start and end dates
    start_date = datetime(2020, 1, 1).strftime('%Y%m%d')
    end_date = datetime(2021, 12, 31).strftime('%Y%m%d')

    # Set the COVID-19 Tracking Project API endpoint URL
    url = f'https://api.covidtracking.com/v1/states/daily.json?state=&after={start_date}&before={end_date}'

    # Send a request to the API endpoint and get the response
    response = requests.get(url)

    # Parse the response JSON and create a pandas dataframe
    data = response.json()
    df = pd.DataFrame(data)

    # Convert the date column to a datetime object
    df['date'] = pd.to_datetime(df['date'], format='%Y%m%d')

    # Group the data by state and by month
    df['month'] = df['date'].dt.to_period('M')
    df_grouped = df.groupby(['state', 'month']).agg({'positive': 'sum', 'death': 'sum'}).reset_index()

    # Create a list of all states
    states = df['state'].unique()

    # Create a list of all months between start_date and end_date
    date_range = pd.date_range(start=start_date, end=end_date, freq='M').to_period('M')

    #Replace 0s with NaN
    df_grouped = df_grouped.replace({0.0: np.nan})
    #Fill NaN with values from before or after
    df_grouped = df_grouped.fillna(method='ffill').fillna(method='bfill')

    # Loop over all states and all months and create a dataframe for each state-month combination
    dfs = []
    for state in states:
        for month in date_range:
            state_data = df_grouped[(df_grouped['state'] == state) & (df_grouped['month'] == month)]
            if state_data.empty:
                state_data = pd.DataFrame({
                    'state': [state],
                    'month': [month],
                    'positive': [np.nan],
                    'death': [np.nan]
                })
            dfs.append(state_data)

    # Concatenate all dataframes into one
    df_final = pd.concat(dfs, ignore_index=True)
    df_final = df_final.groupby('state').apply(lambda group: group.ffill().bfill())
    # Create a new column for the year information
    df_final['year'] = df_final['month'].dt.year

    # Group the dataframe by state and year
    df_grouped = df_final.groupby(['state', 'year']).agg({'positive': 'sum', 'death': 'sum'}).reset_index()
    #Drop non-official US states from states list (since not part of official 50 states)
    df_grouped = df_grouped[(df_grouped['state'] != 'DC') & (df_grouped['state'] != 'AS') & (df_grouped['state'] != 'GU') & (df_grouped['state'] != 'MP') & (df_grouped['state'] != 'VI') & (df_grouped['state'] != 'PR')]

    # Define the dictionary to map abbreviated state names to full names
    states_dict = {
        'AL': 'Alabama',
        'AK': 'Alaska',
        'AZ': 'Arizona',
        'AR': 'Arkansas',
        'CA': 'California',
        'CO': 'Colorado',
        'CT': 'Connecticut',
        'DE': 'Delaware',
        'FL': 'Florida',
        'GA': 'Georgia',
        'HI': 'Hawaii',
        'ID': 'Idaho',
        'IL': 'Illinois',
        'IN': 'Indiana',
        'IA': 'Iowa',
        'KS': 'Kansas',
        'KY': 'Kentucky',
        'LA': 'Louisiana',
        'ME': 'Maine',
        'MD': 'Maryland',
        'MA': 'Massachusetts',
        'MI': 'Michigan',
        'MN': 'Minnesota',
        'MS': 'Mississippi',
        'MO': 'Missouri',
        'MT': 'Montana',
        'NE': 'Nebraska',
        'NV': 'Nevada',
        'NH': 'New Hampshire',
        'NJ': 'New Jersey',
        'NM': 'New Mexico',
        'NY': 'New York',
        'NC': 'North Carolina',
        'ND': 'North Dakota',
        'OH': 'Ohio',
        'OK': 'Oklahoma',
        'OR': 'Oregon',
        'PA': 'Pennsylvania',
        'RI': 'Rhode Island',
        'SC': 'South Carolina',
        'SD': 'South Dakota',
        'TN': 'Tennessee',
        'TX': 'Texas',
        'UT': 'Utah',
        'VT': 'Vermont',
        'VA': 'Virginia',
        'WA': 'Washington',
        'WV': 'West Virginia',
        'WI': 'Wisconsin',
        'WY': 'Wyoming'
    }

    # Assuming your dataframe is called 'df', replace the abbreviated state names with the full names
    df_grouped['state'] = df_grouped['state'].replace(states_dict)

    #Capitalize all the column names 
    df_grouped = df_grouped.rename(columns={'state': 'State'})
    df_grouped = df_grouped.rename(columns={'year': 'Year'})
    df_grouped = df_grouped.rename(columns={'positive': 'Positive'})
    df_grouped = df_grouped.rename(columns={'death': 'Deaths'})
    
    return df_grouped

