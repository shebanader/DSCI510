#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def scrape_weather_data():   
    #Import necessary libraries
    import requests
    from bs4 import BeautifulSoup
    import pandas as pd 
    import numpy as np
    from datetime import datetime, timedelta
    # Send a request to the website
    url = 'https://www.extremeweatherwatch.com/us-state-averages'
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')

    # Find the table containing the data
    table = soup.find('table', {'class': 'bordered-table sort-table'})

    # Extract the table headers
    headers = []
    for column in table.find_all('th'):
        headers.append(column.text.strip())

    # Extract the table data
    data = []
    for row in table.find_all('tr'):
        rows = []
        for values in row.find_all('td'):
            rows.append(values.text.strip())
            if len(row) > 0:
                data.append(rows)

    # Convert the data into a Pandas DataFrame
    weather_df = pd.DataFrame(data, columns=headers)

    # Convert the columns for temperature and precipitation to numeric values and rename city column 
    weather_df = weather_df.rename(columns={'City': 'State'})
    weather_df['High (°F)'] = pd.to_numeric(weather_df['High (°F)'])
    weather_df['Low (°F)'] = pd.to_numeric(weather_df['Low (°F)'])
    weather_df['Precipitation (in)'] = pd.to_numeric(weather_df['Precipitation (in)'])

    # Drop any duplicate rows
    weather_df = weather_df.drop_duplicates()
    weather_df = weather_df.reset_index(drop=True)
    
    return weather_df

