#!/usr/bin/env python
# coding: utf-8

# In[2]:


import argparse
import pandas as pd
import sys
import os 

# Get the current working directory
cwd = os.getcwd()

# Import the Python files for scraping data
sys.path.append(os.path.join(cwd, 'DSCI510_FinalProj'))
import weather_scrape


if __name__ == '__main__':
    # Parse the command line arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('--scrape', type=int, help='Print the first N entries of the dataset')
    parser.add_argument('--save', help='Save the dataset to a CSV file')
    args = parser.parse_args()
    
    df = weather_scrape.scrape_weather_data()

    # Check if N is passed and print the first N entries of the dataset
    if args.scrape is not None:
        print(df.head(args.scrape))
    # Check if save_path is passed and save the dataset to the file
    elif args.save is not None:
        df.to_csv(args.save, index=False)
    # Otherwise, print the complete scraped dataset as rows of data
    else:
        print(df)

